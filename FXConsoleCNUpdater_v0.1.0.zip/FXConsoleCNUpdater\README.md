# FXConsole CN Updater

Generic CEP updater panel for After Effects.

The panel reads `profiles.json`, checks an update manifest, downloads the plugin from the configured mirror, verifies SHA256, and creates an elevated installer script that waits for After Effects to close before replacing the target file.

## Configure

Edit `profiles.json`:

- `name`: label shown in the panel.
- `installPath`: target file path. Environment variables such as `%ProgramFiles%` are supported.
- `manifestUrls`: mainland mirror first, GitHub second.

The manifest format matches `latest.json` from the release package.

## Install Panel

Run PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install_cep_updater.ps1
```

Restart After Effects, then open:

```text
Window > Extensions > FXConsole CN Updater
```

## Privacy

This package contains no local workspace paths, user names, screenshots, tokens, or private notes. Run `sanitize_check.ps1` before publishing.
