(function () {
  "use strict";

  const fs = require("fs");
  const path = require("path");
  const os = require("os");
  const crypto = require("crypto");
  const http = require("http");
  const https = require("https");
  const childProcess = require("child_process");

  const state = {
    profiles: [],
    profile: null,
    manifest: null,
    downloadedFile: null,
    installScript: null
  };

  const $ = (id) => document.getElementById(id);

  function log(message) {
    const line = "[" + new Date().toLocaleTimeString() + "] " + message;
    $("log").textContent += line + "\n";
    $("log").scrollTop = $("log").scrollHeight;
  }

  function setRuntime(message) {
    $("runtimeState").textContent = message;
  }

  function setButtons() {
    $("downloadButton").disabled = !state.manifest;
    $("installButton").disabled = !state.downloadedFile;
    $("scriptButton").disabled = !state.downloadedFile;
  }

  function expandEnv(value) {
    return value.replace(/%([^%]+)%/g, function (_, name) {
      return process.env[name] || process.env[name.toUpperCase()] || "";
    });
  }

  function readJson(filePath) {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  }

  function isPlaceholder(url) {
    return /REPLACE_OWNER|REPLACE_REPO/.test(url);
  }

  function requestBuffer(url, redirectsLeft) {
    return new Promise(function (resolve, reject) {
      const client = url.startsWith("https:") ? https : http;
      const req = client.get(url, { timeout: 20000 }, function (res) {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirectsLeft > 0) {
          res.resume();
          const nextUrl = new URL(res.headers.location, url).toString();
          requestBuffer(nextUrl, redirectsLeft - 1).then(resolve, reject);
          return;
        }

        if (res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          reject(new Error("HTTP " + res.statusCode + " for " + url));
          return;
        }

        const chunks = [];
        res.on("data", function (chunk) { chunks.push(chunk); });
        res.on("end", function () { resolve(Buffer.concat(chunks)); });
      });

      req.on("timeout", function () {
        req.destroy(new Error("Timeout for " + url));
      });
      req.on("error", reject);
    });
  }

  async function requestJson(url) {
    const buffer = await requestBuffer(url, 4);
    return JSON.parse(buffer.toString("utf8"));
  }

  function sha256File(filePath) {
    const hash = crypto.createHash("sha256");
    hash.update(fs.readFileSync(filePath));
    return hash.digest("hex").toUpperCase();
  }

  function ensureDir(dir) {
    fs.mkdirSync(dir, { recursive: true });
  }

  function getAeYearFromHost() {
    try {
      if (!window.__adobe_cep__ || !window.__adobe_cep__.getHostEnvironment) {
        return null;
      }

      const env = JSON.parse(window.__adobe_cep__.getHostEnvironment());
      const version = String(env.appVersion || "");
      const major = Number(version.split(".")[0]);
      if (major >= 20 && major <= 99) {
        return String(2000 + major);
      }
    } catch (error) {
      log("读取 AE 版本失败: " + error.message);
    }

    return null;
  }

  function describeLocalState(installPath, manifest) {
    if (!fs.existsSync(installPath)) {
      return "未检测到 FXConsole";
    }

    const localHash = sha256File(installPath);
    if (manifest && localHash === String(manifest.sha256 || "").toUpperCase()) {
      return "已是最新版";
    }

    if (manifest) {
      return "检测到原版/旧版，可安装中文补丁 / " + localHash.slice(0, 12);
    }

    return "检测到 FXConsole / " + localHash.slice(0, 12);
  }


  function loadProfiles() {
    const configPath = path.join(__dirname, "profiles.json");
    const config = readJson(configPath);
    state.profiles = config.profiles || [];
    const select = $("profileSelect");
    select.innerHTML = "";

    state.profiles.forEach(function (profile, index) {
      const option = document.createElement("option");
      option.value = String(index);
      option.textContent = profile.name;
      select.appendChild(option);
    });

    const hostYear = getAeYearFromHost();
    if (hostYear) {
      const matchIndex = state.profiles.findIndex(function (profile) {
        return String(profile.aeYear || "") === hostYear;
      });
      if (matchIndex >= 0) {
        select.value = String(matchIndex);
        log("检测到当前 AE 版本: " + hostYear);
      }
    }

    state.profile = state.profiles[Number(select.value)] || state.profiles[0] || null;
    updateProfileView();
  }

  function updateProfileView() {
    state.profile = state.profiles[Number($("profileSelect").value)] || state.profiles[0] || null;
    state.manifest = null;
    state.downloadedFile = null;
    state.installScript = null;
    $("remoteVersion").textContent = "-";
    $("downloadSource").textContent = "-";
    $("notesList").innerHTML = "";

    if (!state.profile) {
      $("installPath").textContent = "-";
      $("localState").textContent = "没有 profile";
      setButtons();
      return;
    }

    const installPath = expandEnv(state.profile.installPath);
    $("installPath").textContent = installPath;
    if (fs.existsSync(installPath)) {
      $("localState").textContent = "已安装 / " + sha256File(installPath).slice(0, 12);
    } else {
      $("localState").textContent = "未找到";
    }
    setButtons();
  }

  async function loadManifest() {
    if (!state.profile) {
      throw new Error("No profile selected.");
    }

    const urls = state.profile.manifestUrls || [];
    for (const url of urls) {
      if (isPlaceholder(url)) {
        log("跳过未配置地址: " + url);
        continue;
      }

      try {
        log("检查清单: " + url);
        const manifest = await requestJson(url);
        $("downloadSource").textContent = url;
        return manifest;
      } catch (error) {
        log("清单失败: " + error.message);
      }
    }

    const localManifest = path.join(__dirname, "latest.json");
    if (fs.existsSync(localManifest)) {
      log("使用本地清单: " + localManifest);
      $("downloadSource").textContent = "local";
      return readJson(localManifest);
    }

    throw new Error("没有可用更新清单。请先配置 GitHub/Gitee 地址。");
  }

  async function checkUpdate() {
    setRuntime("检查中");
    state.manifest = await loadManifest();
    state.downloadedFile = null;
    state.installScript = null;

    $("remoteVersion").textContent = state.manifest.version || "-";
    $("notesList").innerHTML = "";
    (state.manifest.notes || []).forEach(function (note) {
      const item = document.createElement("li");
      item.textContent = note;
      $("notesList").appendChild(item);
    });

    const installPath = expandEnv(state.profile.installPath);
    if (fs.existsSync(installPath)) {
      const localHash = sha256File(installPath);
      $("localState").textContent = localHash === state.manifest.sha256.toUpperCase()
        ? "已是最新版"
        : "可更新 / " + localHash.slice(0, 12);
    } else {
      $("localState").textContent = "未找到安装文件";
    }

    log("最新版本: " + state.manifest.version);
    setRuntime("就绪");
    setButtons();
  }

  async function downloadUpdate() {
    if (!state.manifest) {
      throw new Error("请先检查更新。");
    }

    setRuntime("下载中");
    const tempDir = path.join(os.tmpdir(), "ae-plugin-updater", state.manifest.version || "latest");
    ensureDir(tempDir);
    const outFile = path.join(tempDir, state.manifest.fileName || "FXConsole.aex");

    for (const item of state.manifest.downloads || []) {
      if (!item.url || isPlaceholder(item.url)) {
        continue;
      }

      try {
        log("下载: " + item.name);
        const buffer = await requestBuffer(item.url, 4);
        fs.writeFileSync(outFile, buffer);
        assertDownloadedHash(outFile);
        state.downloadedFile = outFile;
        $("downloadSource").textContent = item.name;
        log("下载完成并已校验: " + outFile);
        setRuntime("就绪");
        setButtons();
        return;
      } catch (error) {
        log("下载失败: " + item.name + " / " + error.message);
      }
    }

    const localPackage = path.join(__dirname, state.manifest.fileName || "FXConsole.aex");
    if (fs.existsSync(localPackage)) {
      log("使用本地包: " + localPackage);
      fs.copyFileSync(localPackage, outFile);
      assertDownloadedHash(outFile);
      state.downloadedFile = outFile;
      $("downloadSource").textContent = "local";
      setRuntime("就绪");
      setButtons();
      return;
    }

    throw new Error("没有可用下载源。请配置镜像 URL 或把包放在面板目录。");
  }

  function assertDownloadedHash(filePath) {
    const actual = sha256File(filePath);
    const expected = String(state.manifest.sha256 || "").toUpperCase();
    if (actual !== expected) {
      throw new Error("SHA256 不一致: " + actual);
    }
  }

  function psSingleQuoted(value) {
    return "'" + String(value).replace(/'/g, "''") + "'";
  }

  function writeInstallScript() {
    if (!state.downloadedFile) {
      throw new Error("请先下载更新。");
    }

    const scriptDir = path.dirname(state.downloadedFile);
    const scriptPath = path.join(scriptDir, "apply_update.ps1");
    const installPath = expandEnv(state.profile.installPath);
    const expected = String(state.manifest.sha256 || "").toUpperCase();

    const script = [
      "$ErrorActionPreference = \"Stop\"",
      "$null = & \"$env:SystemRoot\\System32\\chcp.com\" 65001",
      "[Console]::InputEncoding = [System.Text.Encoding]::UTF8",
      "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
      "$OutputEncoding = [System.Text.Encoding]::UTF8",
      "$Host.UI.RawUI.WindowTitle = '\u8d85\u7ea7\u63d2\u4ef6\u7ba1\u7406\u4e2d\u5fc3 - \u5b89\u88c5\u4e2d\u6587\u8865\u4e01'",
      "$hudWidth = 58",
      "function Get-CellWidth([string]$Text) {",
      "  $width = 0",
      "  foreach ($ch in $Text.ToCharArray()) {",
      "    $code = [int][char]$ch",
      "    if (($code -ge 0x2E80 -and $code -le 0x9FFF) -or ($code -ge 0xFF00 -and $code -le 0xFFEF)) { $width += 2 } else { $width += 1 }",
      "  }",
      "  return $width",
      "}",
      "function Write-HudLine([string]$Text, [string]$Color = 'Yellow') {",
      "  $pad = [Math]::Max(0, $hudWidth - (Get-CellWidth $Text))",
      "  Write-Host ('| ' + $Text + (' ' * $pad) + ' |') -ForegroundColor $Color",
      "}",
      "function Write-HudBox([string[]]$Lines) {",
      "  Write-Host ('+' + ('-' * 60) + '+') -ForegroundColor Yellow",
      "  foreach ($line in $Lines) { Write-HudLine $line }",
      "  Write-Host ('+' + ('-' * 60) + '+') -ForegroundColor Yellow",
      "}",
      "$source = " + psSingleQuoted(state.downloadedFile),
      "$destination = " + psSingleQuoted(installPath),
      "$expected = " + psSingleQuoted(expected),
      "Write-Host ''",
      "Write-HudBox @('SUPER PLUGIN CONTROL // \u4e2d\u6587\u8865\u4e01\u90e8\u7f72', 'MODE  : AUTO PATCH', 'TARGET: FXConsole.aex', 'STATE : WAITING FOR AE EXIT')",
      "Write-Host ''",
      "Write-Host '\u8bf7\u5148\u4fdd\u5b58\u5de5\u7a0b\uff0c\u7136\u540e\u5173\u95ed After Effects\u3002' -ForegroundColor Cyan",
      "Write-Host 'AE \u5b8c\u5168\u9000\u51fa\u540e\uff0c\u6211\u4f1a\u81ea\u52a8\u5907\u4efd\u539f\u6587\u4ef6\u5e76\u5b89\u88c5\u4e2d\u6587\u8865\u4e01\u3002' -ForegroundColor DarkCyan",
      "Write-Host ''",
      "$frames = @('[=---]', '[==--]', '[===-]', '[====]', '[-===]', '[--==]', '[---=]')",
      "$i = 0",
      "while (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) {",
      "  Write-Host (\"`rAE \u8fd8\u5728\u8fd0\u884c\uff0c\u7b49\u5f85\u5173\u95ed\u4e2d... \" + $frames[$i % $frames.Count]) -NoNewline -ForegroundColor Yellow",
      "  $i++",
      "  Start-Sleep -Seconds 1",
      "}",
      "Write-Host ''",
      "Write-Host ''",
      "Write-HudLine 'AE \u5df2\u5173\u95ed\uff0c\u8fdb\u5165\u8865\u4e01\u5199\u5165\u6d41\u7a0b' 'Green'",
      "Write-HudLine '\u6b63\u5728\u6821\u9a8c\u8865\u4e01\u5b8c\u6574\u6027\uff1aSHA256' 'Cyan'",
      "$actual = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToUpperInvariant()",
      "if ($actual -ne $expected) { throw \"SHA256 mismatch: $actual\" }",
      "Write-HudLine '\u6821\u9a8c\u901a\u8fc7\uff0c\u51c6\u5907\u5b89\u88c5' 'Green'",
      "$dir = Split-Path -Parent $destination",
      "if (-not (Test-Path -LiteralPath $dir)) { throw \"Install directory does not exist: $dir\" }",
      "if (Test-Path -LiteralPath $destination) {",
      "  $stamp = Get-Date -Format \"yyyyMMdd-HHmmss\"",
      "  $backup = \"$destination.bak.$stamp\"",
      "  Copy-Item -LiteralPath $destination -Destination $backup -Force",
      "  Write-HudLine \"\u5df2\u5907\u4efd\u539f\u6587\u4ef6\" \"Green\"",
      "  Write-Host $backup -ForegroundColor DarkGray",
      "}",
      "Copy-Item -LiteralPath $source -Destination $destination -Force",
      "Write-Host ''",
      "Write-HudBox @('PATCH COMPLETE', '\u4e2d\u6587 FXConsole \u5df2\u90e8\u7f72', '\u91cd\u542f AE \u540e\u81ea\u52a8\u52a0\u8f7d', '\u4efb\u52a1\u5b8c\u6210\uff0c\u8f9b\u82e6\u5566 (>_<)/')",
      "Write-Host $destination -ForegroundColor DarkGray",
      "Write-Host ''",
      "Read-Host '? Enter \u5df2\u5907\u4efd\u539f\u6587\u4ef6'"
    ].join("\r\n");

    fs.writeFileSync(scriptPath, "\ufeff" + script, "utf16le");
    state.installScript = scriptPath;
    log("已准备系统授权安装。");
    setButtons();
    return scriptPath;
  }

  function openFolder(filePath) {
    childProcess.spawn("explorer.exe", ["/select,", filePath], { detached: true, windowsHide: true });
  }

  function runInstallScriptElevated(scriptPath) {
    const vbsPath = path.join(path.dirname(scriptPath), "run_update_as_admin.vbs");
    const args = '-NoProfile -ExecutionPolicy Bypass -File "' + scriptPath + '"';
    const vbs = [
      'Set shell = CreateObject("Shell.Application")',
      'shell.ShellExecute "powershell.exe", "' + args.replace(/"/g, '""') + '", "", "runas", 1'
    ].join("\r\n");
    fs.writeFileSync(vbsPath, vbs, "utf8");
    childProcess.spawn("wscript.exe", [vbsPath], {
      detached: true,
      windowsHide: false
    });
    log("已请求管理员授权。请同意 UAC，然后关闭 AE，系统会自动替换文件。");
  }

  function directInstall() {
    if (!state.downloadedFile) {
      throw new Error("请先下载更新。");
    }

    const installPath = expandEnv(state.profile.installPath);
    const installDir = path.dirname(installPath);
    if (!fs.existsSync(installDir)) {
      throw new Error("安装目录不存在: " + installDir);
    }

    assertDownloadedHash(state.downloadedFile);

    try {
      if (fs.existsSync(installPath)) {
        const stamp = new Date().toISOString().replace(/[:.]/g, "-");
        const backup = installPath + ".bak." + stamp;
        fs.copyFileSync(installPath, backup);
        log("已备份: " + backup);
      }

      fs.copyFileSync(state.downloadedFile, installPath);
      log("已直接替换: " + installPath);
      log("请重启 AE，FXConsole 会自动加载中文补丁。");
      $("localState").textContent = describeLocalState(installPath, state.manifest);
    } catch (error) {
      log("直接替换失败: " + error.message);
      log("通常是权限不足或 AE 正在占用文件。正在切换到系统授权安装。");
      const scriptPath = writeInstallScript();
      runInstallScriptElevated(scriptPath);
    }
  }


  async function oneClickUpdate() {
    setRuntime("更新中");
    await checkUpdate();

    const installPath = expandEnv(state.profile.installPath);
    if (fs.existsSync(installPath) && state.manifest) {
      const localHash = sha256File(installPath);
      if (localHash === String(state.manifest.sha256 || "").toUpperCase()) {
        log("已经是最新版，无需更新。");
        setRuntime("就绪");
        setButtons();
        return;
      }
    }

    await downloadUpdate();
    directInstall();
    setRuntime("就绪");
    setButtons();
  }

  function wrap(action) {
    return function () {
      Promise.resolve()
        .then(action)
        .catch(function (error) {
          setRuntime("错误");
          log("错误: " + error.message);
          setButtons();
        });
    };
  }

  $("profileSelect").addEventListener("change", updateProfileView);
  $("checkButton").addEventListener("click", wrap(oneClickUpdate));
  $("downloadButton").addEventListener("click", wrap(downloadUpdate));
  $("installButton").addEventListener("click", wrap(directInstall));
  $("scriptButton").addEventListener("click", wrap(function () {
    const scriptPath = writeInstallScript();
    openFolder(scriptPath);
  }));

  loadProfiles();
  log("面板已加载。");
})();
