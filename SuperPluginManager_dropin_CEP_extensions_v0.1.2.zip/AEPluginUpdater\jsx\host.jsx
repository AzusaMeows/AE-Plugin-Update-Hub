function fxconsoleCnUpdaterPing() {
    return "ok";
}
