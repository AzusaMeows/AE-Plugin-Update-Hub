$ErrorActionPreference = "Stop"

$extensionName = "AEPluginUpdater"
$source = $PSScriptRoot
$targetRoot = Join-Path $env:APPDATA "Adobe\CEP\extensions"
$target = Join-Path $targetRoot $extensionName

New-Item -ItemType Directory -Force -Path $targetRoot | Out-Null
if (Test-Path -LiteralPath $target) {
    Remove-Item -LiteralPath $target -Recurse -Force
}

Copy-Item -LiteralPath $source -Destination $target -Recurse -Force

foreach ($version in 9..12) {
    $debugKey = "HKCU:\Software\Adobe\CSXS.$version"
    New-Item -Path $debugKey -Force | Out-Null
    Set-ItemProperty -Path $debugKey -Name PlayerDebugMode -Value "1"
}

Write-Host "Installed CEP updater: $target"
Write-Host "Restart After Effects, then open Window > Extensions > AE Plugin Updater."
