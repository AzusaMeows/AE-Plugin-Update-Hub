(function () {
  "use strict";

  const fs = require("fs");
  const path = require("path");
  const os = require("os");
  const crypto = require("crypto");
  const http = require("http");
  const https = require("https");
  const childProcess = require("child_process");

  const state = {
    profiles: [],
    profile: null,
    manifest: null,
    downloadedFile: null,
    installScript: null
  };

  const $ = (id) => document.getElementById(id);

  function log(message) {
    const line = "[" + new Date().toLocaleTimeString() + "] " + message;
    $("log").textContent += line + "\n";
    $("log").scrollTop = $("log").scrollHeight;
  }

  function setRuntime(message) {
    $("runtimeState").textContent = message;
  }

  function setButtons() {
    $("downloadButton").disabled = !state.manifest;
    $("installButton").disabled = !state.downloadedFile;
    $("scriptButton").disabled = !state.downloadedFile;
  }

  function expandEnv(value) {
    return value.replace(/%([^%]+)%/g, function (_, name) {
      return process.env[name] || process.env[name.toUpperCase()] || "";
    });
  }

  function readJson(filePath) {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  }

  function isPlaceholder(url) {
    return /REPLACE_OWNER|REPLACE_REPO/.test(url);
  }

  function requestBuffer(url, redirectsLeft) {
    return new Promise(function (resolve, reject) {
      const client = url.startsWith("https:") ? https : http;
      const req = client.get(url, { timeout: 20000 }, function (res) {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirectsLeft > 0) {
          res.resume();
          const nextUrl = new URL(res.headers.location, url).toString();
          requestBuffer(nextUrl, redirectsLeft - 1).then(resolve, reject);
          return;
        }

        if (res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          reject(new Error("HTTP " + res.statusCode + " for " + url));
          return;
        }

        const chunks = [];
        res.on("data", function (chunk) { chunks.push(chunk); });
        res.on("end", function () { resolve(Buffer.concat(chunks)); });
      });

      req.on("timeout", function () {
        req.destroy(new Error("Timeout for " + url));
      });
      req.on("error", reject);
    });
  }

  async function requestJson(url) {
    const buffer = await requestBuffer(url, 4);
    return JSON.parse(buffer.toString("utf8"));
  }

  function sha256File(filePath) {
    const hash = crypto.createHash("sha256");
    hash.update(fs.readFileSync(filePath));
    return hash.digest("hex").toUpperCase();
  }

  function ensureDir(dir) {
    fs.mkdirSync(dir, { recursive: true });
  }

  function loadProfiles() {
    const configPath = path.join(__dirname, "profiles.json");
    const config = readJson(configPath);
    state.profiles = config.profiles || [];
    const select = $("profileSelect");
    select.innerHTML = "";

    state.profiles.forEach(function (profile, index) {
      const option = document.createElement("option");
      option.value = String(index);
      option.textContent = profile.name;
      select.appendChild(option);
    });

    state.profile = state.profiles[0] || null;
    updateProfileView();
  }

  function updateProfileView() {
    state.profile = state.profiles[Number($("profileSelect").value)] || state.profiles[0] || null;
    state.manifest = null;
    state.downloadedFile = null;
    state.installScript = null;
    $("remoteVersion").textContent = "-";
    $("downloadSource").textContent = "-";
    $("notesList").innerHTML = "";

    if (!state.profile) {
      $("installPath").textContent = "-";
      $("localState").textContent = "没有 profile";
      setButtons();
      return;
    }

    const installPath = expandEnv(state.profile.installPath);
    $("installPath").textContent = installPath;
    if (fs.existsSync(installPath)) {
      $("localState").textContent = "已安装 / " + sha256File(installPath).slice(0, 12);
    } else {
      $("localState").textContent = "未找到";
    }
    setButtons();
  }

  async function loadManifest() {
    if (!state.profile) {
      throw new Error("No profile selected.");
    }

    const urls = state.profile.manifestUrls || [];
    for (const url of urls) {
      if (isPlaceholder(url)) {
        log("跳过未配置地址: " + url);
        continue;
      }

      try {
        log("检查清单: " + url);
        const manifest = await requestJson(url);
        $("downloadSource").textContent = url;
        return manifest;
      } catch (error) {
        log("清单失败: " + error.message);
      }
    }

    const localManifest = path.join(__dirname, "latest.json");
    if (fs.existsSync(localManifest)) {
      log("使用本地清单: " + localManifest);
      $("downloadSource").textContent = "local";
      return readJson(localManifest);
    }

    throw new Error("没有可用更新清单。请先配置 GitHub/Gitee 地址。");
  }

  async function checkUpdate() {
    setRuntime("检查中");
    state.manifest = await loadManifest();
    state.downloadedFile = null;
    state.installScript = null;

    $("remoteVersion").textContent = state.manifest.version || "-";
    $("notesList").innerHTML = "";
    (state.manifest.notes || []).forEach(function (note) {
      const item = document.createElement("li");
      item.textContent = note;
      $("notesList").appendChild(item);
    });

    const installPath = expandEnv(state.profile.installPath);
    if (fs.existsSync(installPath)) {
      const localHash = sha256File(installPath);
      $("localState").textContent = localHash === state.manifest.sha256.toUpperCase()
        ? "已是最新版"
        : "可更新 / " + localHash.slice(0, 12);
    } else {
      $("localState").textContent = "未找到安装文件";
    }

    log("最新版本: " + state.manifest.version);
    setRuntime("就绪");
    setButtons();
  }

  async function downloadUpdate() {
    if (!state.manifest) {
      throw new Error("请先检查更新。");
    }

    setRuntime("下载中");
    const tempDir = path.join(os.tmpdir(), "ae-plugin-updater", state.manifest.version || "latest");
    ensureDir(tempDir);
    const outFile = path.join(tempDir, state.manifest.fileName || "FXConsole.aex");

    for (const item of state.manifest.downloads || []) {
      if (!item.url || isPlaceholder(item.url)) {
        continue;
      }

      try {
        log("下载: " + item.name);
        const buffer = await requestBuffer(item.url, 4);
        fs.writeFileSync(outFile, buffer);
        assertDownloadedHash(outFile);
        state.downloadedFile = outFile;
        $("downloadSource").textContent = item.name;
        log("下载完成并已校验: " + outFile);
        setRuntime("就绪");
        setButtons();
        return;
      } catch (error) {
        log("下载失败: " + item.name + " / " + error.message);
      }
    }

    const localPackage = path.join(__dirname, state.manifest.fileName || "FXConsole.aex");
    if (fs.existsSync(localPackage)) {
      log("使用本地包: " + localPackage);
      fs.copyFileSync(localPackage, outFile);
      assertDownloadedHash(outFile);
      state.downloadedFile = outFile;
      $("downloadSource").textContent = "local";
      setRuntime("就绪");
      setButtons();
      return;
    }

    throw new Error("没有可用下载源。请配置镜像 URL 或把包放在面板目录。");
  }

  function assertDownloadedHash(filePath) {
    const actual = sha256File(filePath);
    const expected = String(state.manifest.sha256 || "").toUpperCase();
    if (actual !== expected) {
      throw new Error("SHA256 不一致: " + actual);
    }
  }

  function psSingleQuoted(value) {
    return "'" + String(value).replace(/'/g, "''") + "'";
  }

  function writeInstallScript() {
    if (!state.downloadedFile) {
      throw new Error("请先下载更新。");
    }

    const scriptDir = path.dirname(state.downloadedFile);
    const scriptPath = path.join(scriptDir, "apply_update.ps1");
    const installPath = expandEnv(state.profile.installPath);
    const expected = String(state.manifest.sha256 || "").toUpperCase();

    const script = [
      "$ErrorActionPreference = \"Stop\"",
      "$source = " + psSingleQuoted(state.downloadedFile),
      "$destination = " + psSingleQuoted(installPath),
      "$expected = " + psSingleQuoted(expected),
      "Write-Host \"Waiting for After Effects to close...\"",
      "while (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 2 }",
      "$actual = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToUpperInvariant()",
      "if ($actual -ne $expected) { throw \"SHA256 mismatch: $actual\" }",
      "$dir = Split-Path -Parent $destination",
      "if (-not (Test-Path -LiteralPath $dir)) { throw \"Install directory does not exist: $dir\" }",
      "if (Test-Path -LiteralPath $destination) {",
      "  $stamp = Get-Date -Format \"yyyyMMdd-HHmmss\"",
      "  Copy-Item -LiteralPath $destination -Destination \"$destination.bak.$stamp\" -Force",
      "}",
      "Copy-Item -LiteralPath $source -Destination $destination -Force",
      "Write-Host \"Updated: $destination\"",
      "Read-Host \"Press Enter to close\""
    ].join("\r\n");

    fs.writeFileSync(scriptPath, script, "utf8");
    state.installScript = scriptPath;
    log("安装脚本: " + scriptPath);
    setButtons();
    return scriptPath;
  }

  function openFolder(filePath) {
    childProcess.spawn("explorer.exe", ["/select,", filePath], { detached: true, windowsHide: true });
  }

  function runElevatedInstall() {
    const scriptPath = state.installScript || writeInstallScript();
    const escaped = scriptPath.replace(/"/g, '\"');
    const command = "Start-Process -FilePath powershell.exe -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File \"" + escaped + "\"'";
    childProcess.spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command], {
      detached: true,
      windowsHide: true
    });
    log("已请求管理员权限。关闭 AE 后脚本会继续替换。");
  }

  function wrap(action) {
    return function () {
      Promise.resolve()
        .then(action)
        .catch(function (error) {
          setRuntime("错误");
          log("错误: " + error.message);
          setButtons();
        });
    };
  }

  $("profileSelect").addEventListener("change", updateProfileView);
  $("checkButton").addEventListener("click", wrap(checkUpdate));
  $("downloadButton").addEventListener("click", wrap(downloadUpdate));
  $("installButton").addEventListener("click", wrap(runElevatedInstall));
  $("scriptButton").addEventListener("click", wrap(function () {
    const scriptPath = writeInstallScript();
    openFolder(scriptPath);
  }));

  loadProfiles();
  log("面板已加载。");
})();
