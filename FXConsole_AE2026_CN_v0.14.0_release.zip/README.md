# FXConsole AE2026 Chinese Patch

This release folder is safe to publish. It contains only the patched plugin, a public update manifest, and updater scripts. It does not include local workspace paths, user names, crash screenshots, or private notes.

## Files

- `FXConsole.aex`: plugin file to publish as a release asset.
- `latest.json`: update manifest with version, SHA256, size, notes, and download URLs.
- `update_fxconsole_cn.ps1`: updater script. It prefers the mainland mirror, then GitHub, then the local file next to the script.
- `sanitize_check.ps1`: quick scan for accidental local/private strings before publishing.

## Publish

1. Create a GitHub release named `v0.14.0`.
2. Upload `FXConsole.aex`, `latest.json`, and `update_fxconsole_cn.ps1`.
3. Create the same release on a mainland mirror such as Gitee.
4. Replace `REPLACE_OWNER` and `REPLACE_REPO` in `latest.json` and `update_fxconsole_cn.ps1`.
5. Run `./sanitize_check.ps1` before uploading.

## Update

Run PowerShell as administrator, then:

```powershell
.\update_fxconsole_cn.ps1
```

The script backs up the current installed `FXConsole.aex`, downloads the new file, verifies SHA256, and replaces the plugin.

This is an unofficial compatibility patch for personal use and testing.
