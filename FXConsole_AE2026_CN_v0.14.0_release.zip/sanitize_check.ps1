$ErrorActionPreference = "Stop"

$patterns = @(
    "azusa",
    "ZJIAN",
    "AppData",
    "Codex",
    "C:\\Users",
    "D:\\"
)

$textFiles = Get-ChildItem -LiteralPath $PSScriptRoot -File |
    Where-Object { $_.Extension -in @(".ps1", ".md", ".json") -and $_.Name -ne "sanitize_check.ps1" }
$hits = foreach ($file in $textFiles) {
    Select-String -LiteralPath $file.FullName -Pattern $patterns -SimpleMatch -ErrorAction SilentlyContinue
}

if ($hits) {
    $hits | ForEach-Object {
        Write-Host "$($_.Path):$($_.LineNumber): $($_.Line)"
    }
    throw "Potential private/local content found."
}

Write-Host "Sanitize check passed."
