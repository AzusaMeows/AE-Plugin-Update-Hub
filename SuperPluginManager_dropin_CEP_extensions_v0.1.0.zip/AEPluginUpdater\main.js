(function () {
  "use strict";

  const fs = require("fs");
  const path = require("path");
  const os = require("os");
  const crypto = require("crypto");
  const http = require("http");
  const https = require("https");
  const childProcess = require("child_process");

  const state = {
    profiles: [],
    profile: null,
    manifest: null,
    downloadedFile: null,
    installScript: null
  };

  const $ = (id) => document.getElementById(id);

  function log(message) {
    const line = "[" + new Date().toLocaleTimeString() + "] " + message;
    $("log").textContent += line + "\n";
    $("log").scrollTop = $("log").scrollHeight;
  }

  function setRuntime(message) {
    $("runtimeState").textContent = message;
  }

  function setButtons() {
    $("downloadButton").disabled = !state.manifest;
    $("installButton").disabled = !state.downloadedFile;
    $("scriptButton").disabled = !state.downloadedFile;
  }

  function expandEnv(value) {
    return value.replace(/%([^%]+)%/g, function (_, name) {
      return process.env[name] || process.env[name.toUpperCase()] || "";
    });
  }

  function readJson(filePath) {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  }

  function isPlaceholder(url) {
    return /REPLACE_OWNER|REPLACE_REPO/.test(url);
  }

  function requestBuffer(url, redirectsLeft) {
    return new Promise(function (resolve, reject) {
      const client = url.startsWith("https:") ? https : http;
      const req = client.get(url, { timeout: 20000 }, function (res) {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirectsLeft > 0) {
          res.resume();
          const nextUrl = new URL(res.headers.location, url).toString();
          requestBuffer(nextUrl, redirectsLeft - 1).then(resolve, reject);
          return;
        }

        if (res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          reject(new Error("HTTP " + res.statusCode + " for " + url));
          return;
        }

        const chunks = [];
        res.on("data", function (chunk) { chunks.push(chunk); });
        res.on("end", function () { resolve(Buffer.concat(chunks)); });
      });

      req.on("timeout", function () {
        req.destroy(new Error("Timeout for " + url));
      });
      req.on("error", reject);
    });
  }

  async function requestJson(url) {
    const buffer = await requestBuffer(url, 4);
    return JSON.parse(buffer.toString("utf8"));
  }

  function sha256File(filePath) {
    const hash = crypto.createHash("sha256");
    hash.update(fs.readFileSync(filePath));
    return hash.digest("hex").toUpperCase();
  }

  function ensureDir(dir) {
    fs.mkdirSync(dir, { recursive: true });
  }

  function getAeYearFromHost() {
    try {
      if (!window.__adobe_cep__ || !window.__adobe_cep__.getHostEnvironment) {
        return null;
      }

      const env = JSON.parse(window.__adobe_cep__.getHostEnvironment());
      const version = String(env.appVersion || "");
      const major = Number(version.split(".")[0]);
      if (major >= 20 && major <= 99) {
        return String(2000 + major);
      }
    } catch (error) {
      log("读取 AE 版本失败: " + error.message);
    }

    return null;
  }

  function describeLocalState(installPath, manifest) {
    if (!fs.existsSync(installPath)) {
      return "未检测到 FXConsole";
    }

    const localHash = sha256File(installPath);
    if (manifest && localHash === String(manifest.sha256 || "").toUpperCase()) {
      return "已是最新版";
    }

    if (manifest) {
      return "检测到原版/旧版，可安装中文补丁 / " + localHash.slice(0, 12);
    }

    return "检测到 FXConsole / " + localHash.slice(0, 12);
  }


  function loadProfiles() {
    const configPath = path.join(__dirname, "profiles.json");
    const config = readJson(configPath);
    state.profiles = config.profiles || [];
    const select = $("profileSelect");
    select.innerHTML = "";

    state.profiles.forEach(function (profile, index) {
      const option = document.createElement("option");
      option.value = String(index);
      option.textContent = profile.name;
      select.appendChild(option);
    });

    const hostYear = getAeYearFromHost();
    if (hostYear) {
      const matchIndex = state.profiles.findIndex(function (profile) {
        return String(profile.aeYear || "") === hostYear;
      });
      if (matchIndex >= 0) {
        select.value = String(matchIndex);
        log("检测到当前 AE 版本: " + hostYear);
      }
    }

    state.profile = state.profiles[Number(select.value)] || state.profiles[0] || null;
    updateProfileView();
  }

  function updateProfileView() {
    state.profile = state.profiles[Number($("profileSelect").value)] || state.profiles[0] || null;
    state.manifest = null;
    state.downloadedFile = null;
    state.installScript = null;
    $("remoteVersion").textContent = "-";
    $("downloadSource").textContent = "-";
    $("notesList").innerHTML = "";

    if (!state.profile) {
      $("installPath").textContent = "-";
      $("localState").textContent = "没有 profile";
      setButtons();
      return;
    }

    const installPath = expandEnv(state.profile.installPath);
    $("installPath").textContent = installPath;
    if (fs.existsSync(installPath)) {
      $("localState").textContent = "已安装 / " + sha256File(installPath).slice(0, 12);
    } else {
      $("localState").textContent = "未找到";
    }
    setButtons();
  }

  async function loadManifest() {
    if (!state.profile) {
      throw new Error("No profile selected.");
    }

    const urls = state.profile.manifestUrls || [];
    for (const url of urls) {
      if (isPlaceholder(url)) {
        log("跳过未配置地址: " + url);
        continue;
      }

      try {
        log("检查清单: " + url);
        const manifest = await requestJson(url);
        $("downloadSource").textContent = url;
        return manifest;
      } catch (error) {
        log("清单失败: " + error.message);
      }
    }

    const localManifest = path.join(__dirname, "latest.json");
    if (fs.existsSync(localManifest)) {
      log("使用本地清单: " + localManifest);
      $("downloadSource").textContent = "local";
      return readJson(localManifest);
    }

    throw new Error("没有可用更新清单。请先配置 GitHub/Gitee 地址。");
  }

  async function checkUpdate() {
    setRuntime("检查中");
    state.manifest = await loadManifest();
    state.downloadedFile = null;
    state.installScript = null;

    $("remoteVersion").textContent = state.manifest.version || "-";
    $("notesList").innerHTML = "";
    (state.manifest.notes || []).forEach(function (note) {
      const item = document.createElement("li");
      item.textContent = note;
      $("notesList").appendChild(item);
    });

    const installPath = expandEnv(state.profile.installPath);
    if (fs.existsSync(installPath)) {
      const localHash = sha256File(installPath);
      $("localState").textContent = localHash === state.manifest.sha256.toUpperCase()
        ? "已是最新版"
        : "可更新 / " + localHash.slice(0, 12);
    } else {
      $("localState").textContent = "未找到安装文件";
    }

    log("最新版本: " + state.manifest.version);
    setRuntime("就绪");
    setButtons();
  }

  async function downloadUpdate() {
    if (!state.manifest) {
      throw new Error("请先检查更新。");
    }

    setRuntime("下载中");
    const tempDir = path.join(os.tmpdir(), "ae-plugin-updater", state.manifest.version || "latest");
    ensureDir(tempDir);
    const outFile = path.join(tempDir, state.manifest.fileName || "FXConsole.aex");

    for (const item of state.manifest.downloads || []) {
      if (!item.url || isPlaceholder(item.url)) {
        continue;
      }

      try {
        log("下载: " + item.name);
        const buffer = await requestBuffer(item.url, 4);
        fs.writeFileSync(outFile, buffer);
        assertDownloadedHash(outFile);
        state.downloadedFile = outFile;
        $("downloadSource").textContent = item.name;
        log("下载完成并已校验: " + outFile);
        setRuntime("就绪");
        setButtons();
        return;
      } catch (error) {
        log("下载失败: " + item.name + " / " + error.message);
      }
    }

    const localPackage = path.join(__dirname, state.manifest.fileName || "FXConsole.aex");
    if (fs.existsSync(localPackage)) {
      log("使用本地包: " + localPackage);
      fs.copyFileSync(localPackage, outFile);
      assertDownloadedHash(outFile);
      state.downloadedFile = outFile;
      $("downloadSource").textContent = "local";
      setRuntime("就绪");
      setButtons();
      return;
    }

    throw new Error("没有可用下载源。请配置镜像 URL 或把包放在面板目录。");
  }

  function assertDownloadedHash(filePath) {
    const actual = sha256File(filePath);
    const expected = String(state.manifest.sha256 || "").toUpperCase();
    if (actual !== expected) {
      throw new Error("SHA256 不一致: " + actual);
    }
  }

  function psSingleQuoted(value) {
    return "'" + String(value).replace(/'/g, "''") + "'";
  }

  function writeInstallScript() {
    if (!state.downloadedFile) {
      throw new Error("请先下载更新。");
    }

    const scriptDir = path.dirname(state.downloadedFile);
    const scriptPath = path.join(scriptDir, "apply_update.ps1");
    const installPath = expandEnv(state.profile.installPath);
    const expected = String(state.manifest.sha256 || "").toUpperCase();

    const script = [
      "$ErrorActionPreference = \"Stop\"",
      "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
      "$OutputEncoding = [System.Text.Encoding]::UTF8",
      "$Host.UI.RawUI.WindowTitle = '超级插件管理中心 - 安装中文补丁'",
      "$source = " + psSingleQuoted(state.downloadedFile),
      "$destination = " + psSingleQuoted(installPath),
      "$expected = " + psSingleQuoted(expected),
      "Write-Host ''",
      "Write-Host '╭────────────────────────────────────────╮'",
      "Write-Host '  超级插件管理中心正在待机安装 (｀・ω・´)'",
      "Write-Host '╰────────────────────────────────────────╯'",
      "Write-Host ''",
      "Write-Host '请先保存工程，然后关闭 After Effects。'",
      "Write-Host 'AE 完全退出后，我会自动备份原文件并安装中文补丁。'",
      "Write-Host ''",
      "while (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) { Write-Host 'AE 还在运行，等待关闭中...'; Start-Sleep -Seconds 3 }",
      "Write-Host ''",
      "Write-Host '检测到 AE 已关闭，开始校验补丁文件...'",
      "$actual = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToUpperInvariant()",
      "if ($actual -ne $expected) { throw \"SHA256 mismatch: $actual\" }",
      "Write-Host '校验通过，开始准备安装。'",
      "$dir = Split-Path -Parent $destination",
      "if (-not (Test-Path -LiteralPath $dir)) { throw \"Install directory does not exist: $dir\" }",
      "if (Test-Path -LiteralPath $destination) {",
      "  $stamp = Get-Date -Format \"yyyyMMdd-HHmmss\"",
      "  $backup = \"$destination.bak.$stamp\"",
      "  Copy-Item -LiteralPath $destination -Destination $backup -Force",
      "  Write-Host \"已备份原文件：$backup\"",
      "}",
      "Copy-Item -LiteralPath $source -Destination $destination -Force",
      "Write-Host ''",
      "Write-Host \"安装完成：$destination\"",
      "Write-Host '重启 AE 后，中文 FXConsole 就会自动加载。'",
      "Write-Host '任务完成，辛苦啦 (ﾉ>ω<)ﾉ'",
      "Write-Host ''",
      "Read-Host '按 Enter 关闭这个窗口'"
    ].join("\r\n");

    fs.writeFileSync(scriptPath, "\ufeff" + script, "utf16le");
    state.installScript = scriptPath;
    log("已准备系统授权安装。");
    setButtons();
    return scriptPath;
  }

  function openFolder(filePath) {
    childProcess.spawn("explorer.exe", ["/select,", filePath], { detached: true, windowsHide: true });
  }

  function runInstallScriptElevated(scriptPath) {
    const vbsPath = path.join(path.dirname(scriptPath), "run_update_as_admin.vbs");
    const args = '-NoProfile -ExecutionPolicy Bypass -File "' + scriptPath + '"';
    const vbs = [
      'Set shell = CreateObject("Shell.Application")',
      'shell.ShellExecute "powershell.exe", "' + args.replace(/"/g, '""') + '", "", "runas", 1'
    ].join("\r\n");
    fs.writeFileSync(vbsPath, vbs, "utf8");
    childProcess.spawn("wscript.exe", [vbsPath], {
      detached: true,
      windowsHide: false
    });
    log("已请求管理员授权。请同意 UAC，然后关闭 AE，系统会自动替换文件。");
  }

  function directInstall() {
    if (!state.downloadedFile) {
      throw new Error("请先下载更新。");
    }

    const installPath = expandEnv(state.profile.installPath);
    const installDir = path.dirname(installPath);
    if (!fs.existsSync(installDir)) {
      throw new Error("安装目录不存在: " + installDir);
    }

    assertDownloadedHash(state.downloadedFile);

    try {
      if (fs.existsSync(installPath)) {
        const stamp = new Date().toISOString().replace(/[:.]/g, "-");
        const backup = installPath + ".bak." + stamp;
        fs.copyFileSync(installPath, backup);
        log("已备份: " + backup);
      }

      fs.copyFileSync(state.downloadedFile, installPath);
      log("已直接替换: " + installPath);
      log("请重启 AE，FXConsole 会自动加载中文补丁。");
      $("localState").textContent = describeLocalState(installPath, state.manifest);
    } catch (error) {
      log("直接替换失败: " + error.message);
      log("通常是权限不足或 AE 正在占用文件。正在切换到系统授权安装。");
      const scriptPath = writeInstallScript();
      runInstallScriptElevated(scriptPath);
    }
  }


  async function oneClickUpdate() {
    setRuntime("更新中");
    await checkUpdate();

    const installPath = expandEnv(state.profile.installPath);
    if (fs.existsSync(installPath) && state.manifest) {
      const localHash = sha256File(installPath);
      if (localHash === String(state.manifest.sha256 || "").toUpperCase()) {
        log("已经是最新版，无需更新。");
        setRuntime("就绪");
        setButtons();
        return;
      }
    }

    await downloadUpdate();
    directInstall();
    setRuntime("就绪");
    setButtons();
  }

  function wrap(action) {
    return function () {
      Promise.resolve()
        .then(action)
        .catch(function (error) {
          setRuntime("错误");
          log("错误: " + error.message);
          setButtons();
        });
    };
  }

  $("profileSelect").addEventListener("change", updateProfileView);
  $("checkButton").addEventListener("click", wrap(oneClickUpdate));
  $("downloadButton").addEventListener("click", wrap(downloadUpdate));
  $("installButton").addEventListener("click", wrap(directInstall));
  $("scriptButton").addEventListener("click", wrap(function () {
    const scriptPath = writeInstallScript();
    openFolder(scriptPath);
  }));

  loadProfiles();
  log("面板已加载。");
})();
